package ir.parshian.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Bitmap
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LocalStore(context: Activity) : SQLiteOpenHelper(context, "parshian.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT, body TEXT NOT NULL, created TEXT NOT NULL)")
        db.execSQL("CREATE TABLE entries(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, title TEXT NOT NULL, amount REAL NOT NULL, created TEXT NOT NULL)")
        db.execSQL("CREATE TABLE tasks(id INTEGER PRIMARY KEY AUTOINCREMENT, body TEXT NOT NULL, done INTEGER NOT NULL DEFAULT 0, created TEXT NOT NULL)")
        db.execSQL("CREATE TABLE photos(id INTEGER PRIMARY KEY AUTOINCREMENT, uri TEXT NOT NULL, created TEXT NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun add(table: String, values: ContentValues) = writableDatabase.insert(table, null, values)
    fun rows(sql: String): List<Array<String>> {
        val out = mutableListOf<Array<String>>()
        readableDatabase.rawQuery(sql, null).use { c ->
            while (c.moveToNext()) out.add(Array(c.columnCount) { i -> c.getString(i) ?: "" })
        }
        return out
    }
    fun run(sql: String, args: Array<String>) { writableDatabase.execSQL(sql, args) }
}

class MainActivity : Activity() {
    private lateinit var store: LocalStore
    private lateinit var root: LinearLayout
    private val ink = 0xFF263238.toInt()
    private val teal = 0xFF087E75.toInt()
    private val cream = 0xFFF5F7F6.toInt()
    private val date get() = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = LocalStore(this)
        showHome()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(s: String, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(ink)
        if (bold) setTypeface(null, Typeface.BOLD)
        gravity = Gravity.RIGHT; textDirection = View.TEXT_DIRECTION_RTL
        setPadding(dp(8), dp(8), dp(8), dp(8))
    }
    private fun action(s: String, run: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; setOnClickListener { run() }
        setTextColor(0xFFFFFFFF.toInt()); setBackgroundColor(teal); textSize = 15f
    }
    private fun setup(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(cream); layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
        root.addView(label("پرشیان", 27f, true)); root.addView(label(title, 18f, true))
    }
    private fun line(s: String) { root.addView(label(s)) }
    private fun gap() { root.addView(View(this), ViewGroup.LayoutParams(1, dp(8))) }
    private fun btn(s: String, run: () -> Unit) {
        val b = action(s, run); val p = LinearLayout.LayoutParams(-1, dp(52))
        p.setMargins(0, dp(5), 0, dp(5)); root.addView(b, p)
    }
    private fun back() = btn("بازگشت به صفحه اصلی") { showHome() }
    private fun showHome() {
        setup("دستیار شخصی و مدیریت روزانه")
        line("نسخه آغازین آفلاین؛ اطلاعات این بخش‌ها روی همین گوشی ذخیره می‌شوند.")
        gap()
        btn("یادداشت‌ها") { showNotes() }
        btn("حسابداری؛ درآمد و هزینه") { showFinance() }
        btn("کارها و وظایف") { showTasks() }
        btn("عکس‌ها و مدارک") { showPhotos() }
        btn("راهنما و وضعیت نسخه") { showAbout() }
    }
    private fun inputDialog(title: String, hint: String, save: (String) -> Unit) {
        val input = EditText(this).apply { this.hint = hint; textDirection = View.TEXT_DIRECTION_RTL }
        AlertDialog.Builder(this).setTitle(title).setView(input)
            .setPositiveButton("ذخیره") { _, _ -> input.text.toString().trim().takeIf { it.isNotEmpty() }?.let(save) }
            .setNegativeButton("انصراف", null).show()
    }
    private fun showNotes() {
        setup("یادداشت‌ها")
        btn("یادداشت جدید") {
            inputDialog("یادداشت جدید", "متن یادداشت را بنویس") {
                store.add("notes", ContentValues().apply { put("body", it); put("created", date) }); showNotes()
            }
        }
        store.rows("SELECT id, body, created FROM notes ORDER BY id DESC").forEach { line("• ${it[1]}\n${it[2]}") }
        back()
    }
    private fun showFinance() {
        setup("حسابداری")
        line("مبلغ‌ها را به تومان وارد کن.")
        btn("ثبت درآمد") { financeDialog("درآمد") }
        btn("ثبت هزینه") { financeDialog("هزینه") }
        var income = 0.0; var expense = 0.0
        store.rows("SELECT kind, SUM(amount) FROM entries GROUP BY kind").forEach {
            val n = it[1].toDoubleOrNull() ?: 0.0
            if (it[0] == "درآمد") income = n else expense = n
        }
        line("جمع درآمد: ${"%.0f".format(Locale.US, income)} تومان")
        line("جمع هزینه: ${"%.0f".format(Locale.US, expense)} تومان")
        line("مانده: ${"%.0f".format(Locale.US, income-expense)} تومان")
        gap(); line("آخرین تراکنش‌ها:")
        store.rows("SELECT kind, title, amount, created FROM entries ORDER BY id DESC LIMIT 30").forEach {
            line("${it[0]} | ${it[1]} | ${it[2]} تومان\n${it[3]}")
        }
        back()
    }
    private fun financeDialog(kind: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20),0,dp(20),0) }
        val title = EditText(this).apply { hint = "عنوان (مثلاً خرید ابزار)"; textDirection = View.TEXT_DIRECTION_RTL }
        val amount = EditText(this).apply { hint = "مبلغ به تومان"; inputType = 2 }
        box.addView(title); box.addView(amount)
        AlertDialog.Builder(this).setTitle("ثبت $kind").setView(box)
            .setPositiveButton("ثبت") { _, _ ->
                val n = amount.text.toString().toDoubleOrNull(); val t = title.text.toString().trim()
                if (n != null && n > 0 && t.isNotEmpty()) {
                    store.add("entries", ContentValues().apply {
                        put("kind", kind); put("title", t); put("amount", n); put("created", date)
                    }); showFinance()
                } else Toast.makeText(this, "عنوان و مبلغ معتبر وارد کن.", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("انصراف", null).show()
    }
    private fun showTasks() {
        setup("کارها و وظایف")
        btn("ثبت کار جدید") {
            inputDialog("کار جدید", "مثلاً تماس با مشتری") {
                store.add("tasks", ContentValues().apply { put("body", it); put("created", date) }); showTasks()
            }
        }
        store.rows("SELECT id, body, done, created FROM tasks ORDER BY done ASC, id DESC").forEach { row ->
            root.addView(label((if (row[2] == "1") "✓ " else "○ ") + row[1] + "\n" + row[3]).apply {
                setOnClickListener {
                    store.run("UPDATE tasks SET done=? WHERE id=?", arrayOf(if (row[2] == "1") "0" else "1", row[0]))
                    showTasks()
                }
            })
        }
        line("برای تغییر وضعیت انجام‌شده، روی هر کار بزن.")
        back()
    }
    private fun showPhotos() {
        setup("عکس‌ها و مدارک")
        line("عکس را با دوربین بگیر یا از گالری انتخاب کن.")
        btn("باز کردن دوربین") {
            try { startActivityForResult(Intent(MediaStore.ACTION_IMAGE_CAPTURE), 301) }
            catch (_: Exception) { Toast.makeText(this, "برنامه دوربین در دسترس نیست.", Toast.LENGTH_SHORT).show() }
        }
        btn("انتخاب عکس از گالری") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) }
            startActivityForResult(i, 302)
        }
        store.rows("SELECT id, uri, created FROM photos ORDER BY id DESC").forEach { line("تصویر: ${it[2]}\n${it[1]}") }
        back()
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        var savedUri: Uri? = null
        if (requestCode == 302) {
            savedUri = data?.data
            if (savedUri != null) try {
                contentResolver.takePersistableUriPermission(savedUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
        } else if (requestCode == 301) {
            val bitmap = data?.extras?.get("data") as? Bitmap
            if (bitmap != null) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, "Parshian_${System.currentTimeMillis()}.jpg")
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                }
                savedUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (savedUri != null) contentResolver.openOutputStream(savedUri!!)?.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            }
        }
        if (savedUri != null) {
            store.add("photos", ContentValues().apply { put("uri", savedUri.toString()); put("created", date) })
            showPhotos()
        } else if (requestCode == 301) {
            Toast.makeText(this, "عکس از دوربین دریافت نشد؛ لطفاً از گالری انتخاب کن.", Toast.LENGTH_LONG).show()
        }
    }
    private fun showAbout() {
        setup("درباره پرشیان")
        line("نسخه آغازین 0.1.0")
        line("امکانات موجود: یادداشت، ثبت درآمد و هزینه، فهرست کارها، انتخاب عکس از گالری و دریافت تصویر کوچک دوربین.")
        line("هنوز پیاده‌سازی نشده: رمز و اثر انگشت، یادآوری زمان‌بندی‌شده، پشتیبان‌گیری رمزگذاری‌شده، همگام‌سازی، فرمان صوتی و خواندن خودکار فاکتور.")
        line("این نسخه هنوز روی گوشی واقعی آزمایش نشده است؛ فعلاً اطلاعات حساس و واقعی وارد نکن.")
        back()
    }
}
